<?php
session_start();
// print_r($_SESSION);

echo "welcome parent dashboard";

?>